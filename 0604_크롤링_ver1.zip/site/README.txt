# 패션 크롤링 사이트 (공유용 HTML)

`site/` 폴더가 **빌드된 정적 웹사이트**입니다.

## 폴더 구조

```
site/
├── index.html          ← 메인 페이지
└── assets/
    ├── index-*.js      ← 앱 코드
    └── index-*.css     ← 스타일
```

## 공유 방법

### 1) 팀원과 LAN 공유 (권장)

백엔드가 HTML + API를 함께 제공합니다.

```bat
scripts\build_and_serve.bat
```

- 본인 PC: http://127.0.0.1:8000
- 같은 Wi-Fi: http://(내 IP):8000

### 2) HTML만 zip으로 전달

`site` 폴더를 zip으로 압축해 전달합니다.  
단, **크롤링 API는 별도 서버**가 필요합니다. HTML만 열면 동작하지 않습니다.

### 3) UI 수정 후 다시 빌드

```bat
scripts\build_site.bat
```

프론트 수정 → 위 스크립트 실행 → `site/` 갱신

## API 서버 주소 변경

프론트를 다른 호스트에 올릴 때, 빌드 전 `.env.production` 생성:

```
VITE_API_URL=http://서버IP:8000/api
```

그다음 `scripts\build_site.bat` 실행.
